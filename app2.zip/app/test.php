<?php
/**
 * Created by PhpStorm.
 * User: karim
 * Date: 01/12/16
 * Time: 01:15 ص
 */
echo phpinfo();

?>
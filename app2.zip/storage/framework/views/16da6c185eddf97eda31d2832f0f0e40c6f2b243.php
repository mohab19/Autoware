<header>
    <div class="container">
        <h4 class="fl-right">
            لوحة التحكم
        </h4>
        <i class="fa fa-bars"></i>
        <i class="fa fa-close"></i>

        <li class="dropdown fl-left list-unstyled">

            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true"
               aria-expanded="false"><?php echo e($user->first_name." ".$user->last_name); ?><span class="caret"></span></a>
            <ul class="dropdown-menu">
                <li><a href="#" data-popup="AccountInfo-Popup"><i class="fa fa-info"></i>بيانات الحساب</a></li>
                <li><a href="<?php echo e(URL::route('logout')); ?>"><i class="fa fa-sign-out"></i>تسحيل الخروج</a></li>
            </ul>
        </li>
        <div class="notifcation fl-left" style="margin-left:50px;margin-top:8px">

            <a href="#" class="notifcation-icon">
                <i class="fa fa-bell-o"></i>
                <?php if($count>0): ?>
                    <span class="number"><?php echo e($count); ?></span>
                    <?php endif; ?>
            </a>
            <ul class="notifcation-body list-unstyled">
                <?php foreach($notifications as $notification): ?>
                    <li
                            <?php if(!$notification->read): ?>
                                class="unread"
                            <?php endif; ?>
                    ><a href="<?php echo e($notification->url); ?>"><?php echo e($notification->title); ?></a>
                        <i data-id="<?php echo e($notification->id); ?>" class="fa fa-remove"></i>
                    </li>
                    <?php endforeach; ?>
            </ul>
        </div>
    </div>
</header>

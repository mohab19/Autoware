<?php $__env->startSection('tab-style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    الوصول السريع
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tab-contents'); ?>
<div role="tabpanel" class="tab-pane fade in active" id="QuickAccess">
    <div class="box col-md-6">
        <!--===== POPUP TITLE -=====-->
        <div class="popup-title">
            <h2>اضافة عميل جديد</h2>
            <br>
            <hr>
            <hr>
        </div>
        <!--===== POPUP BODY ======-->
        <div class="popup-body">
            <?php echo $__env->make('layouts.clients_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
    <div class="box col-md-6">
        <!--===== POPUP TITLE -=====-->
        <div class="popup-title">
            <h2>اضافة حجز جديد</h2>
            <br>
            <hr>
            <hr>
        </div>
        <!--===== POPUP BODY ======-->
        <div class="popup-body">
            <?php echo $__env->make('layouts/reservation_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tab-script'); ?>
    <script src="<?php echo e(asset('AjaxRequests/RegisterClient.js')); ?>"></script>
    <script src="<?php echo e(asset('AjaxRequests/RegisterReservation.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
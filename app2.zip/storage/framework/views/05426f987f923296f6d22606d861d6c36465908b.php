<?php $__env->startSection('tab-style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    مصاريف عامة
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tab-contents'); ?>
    <?php echo $__env->make('layouts.Expenses_Forms', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div role="tabpanel" class="tab-pane fade in active" id="Expenses">
        <section id="General" class="general">
            <button data-popup="AddExpense-Popup" id="AddExpense" class="main-btn">اضافة مصروف جديد</button>
            <div class="expenses box main-box">
                <?php if(sizeof($general_expenses)): ?>
            <table>
                <tr>
                    <?php foreach($expenses_fields as $field): ?>
                        <th> <?php echo e($field); ?> </th>
                    <?php endforeach; ?>
                    <th>التاريخ</th>
                    <th>الموظف</th>
                    <th>الخيارات</th>
                </tr>
                <?php foreach($general_expenses as $general_expense): ?>
                <tr>
                    <td id="title">
                        <?php echo e($general_expense->title); ?>

                    </td>
                    <td id="value">
                        <div class="col-xs-12">
                            <?php echo e($general_expense->value); ?>

                        </div>
                    </td>
                    <td>
                        <div class="col-xs-12">
                            <?php echo e(date_format( new DateTime($general_expense->created_at),"d-m-Y")); ?>

                        </div>
                    </td>
                    <td>
                        <div class="col-xs-12">
                            <?php echo e($general_expense->user->display_name); ?>

                        </div>
                    </td>
                    <td>
                        <button class="main-btn sm-btn" id="EditExpense-btn" data-popup="ExpensesInfo-Popup">
                            <i class="fa fa-pencil"></i>
                        </button>
                        <button class="main-btn sm-btn" data-popup="DeleteExpense-Popup"
                                data-id="<?php echo e($general_expense->id); ?>">
                            <i class="fa fa-remove"></i>
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
                    <?php else: ?>
                <h3 class="text-red text-center">لا توجد اي مصاريف بعد </h3>
                    <?php endif; ?>
            </div>
            </section>

    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('tab-script'); ?>
    <script src="<?php echo e(asset('AjaxRequests/Expenses.js')); ?>"></script>
    <script src="<?php echo e(asset('AjaxRequests/GeneralExpenses.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
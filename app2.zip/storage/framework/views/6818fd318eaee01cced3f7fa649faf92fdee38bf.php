<?php $__env->startSection('tab-style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    الحجوزات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tab-contents'); ?>
    <div id="DeleteReservation-Popup" class="popup">
        <i class="fa fa-close text-danger" data-toggle="tooltip" data-placement="left" title="اغلاق"></i>
        <!--===== POPUP TITLE -=====-->
        <div class="popup-title">
            <h2>حذف الحجز</h2>
            <br>
            <hr>
            <hr>
        </div>
        <!--===== POPUP BODY ======-->
        <div class="popup-body text-center">
            <form id="DeleteReservation" type="POST">
                <h3 class="text-red "> هل انت متأكد بأنك تريد حذف هذا الحجز؟</h3>
                <?php echo csrf_field(); ?>


                <input type="text" class="hidden" name="id" id="IDVal">
                <div class="text-center">
                    <button type="submit" class="main-btn">نعم</button>
                </div>
                <div class="alert"role="alert">

                </div>
            </form>
        </div>
    </div>
    <!-- START ADD Reservation FORM -->
    <div id="AddReservation-Popup" class="popup">
        <i class="fa fa-close text-danger" data-toggle="tooltip" data-placement="left" title="اغلاق"></i>
        <!--===== POPUP TITLE -=====-->
        <div class="popup-title">
            <h2>اضافة حجز جديد</h2>
            <br>
            <hr>
            <hr>
        </div>
        <!--===== POPUP BODY ======-->
        <div class="popup-body">
            <?php echo $__env->make('layouts/reservation_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
    <!-- END ADD Reservation FORM -->  
<!-- START Edit Reservation FORM -->
    <div id="UpdateReservation-Popup" class="popup">
        <i class="fa fa-close text-danger" data-toggle="tooltip" data-placement="left" title="اغلاق"></i>
        <!--===== POPUP TITLE -=====-->
        <div class="popup-title">
            <h2> تعديل الحجز </h2>
            <br>
            <hr>
            <hr>
        </div>
        <!--===== POPUP BODY ======-->
        <div class="popup-body">
           <form id="UpdateReservation">
                 <?php echo csrf_field(); ?>

                <div class="col-xs-12">
        <label style="margin-right:15px;">السيارة</label>
        <input disabled name="car_id">
    </div>
               <div class="col-md-6 col-xs-12">
        <label style="margin-right:15px;">من</label>
        <input name="start_duration" type="date" placeholder="من">
        <label id="reservation_start_duration"></label>
    </div>
    <div class="col-md-6 col-xs-12">
        <label style="margin-right:15px;">الي</label>
        <input name="end_duration" type="date" placeholder="الي">
        <label id="reservation_end_duration"></label>
    </div>
               <div class="col-md-6 col-xs-12">
                   <input name="DiscountOption" value="1" id="withdiscount" type="radio">
                   <label for="withdiscount" style="display:inline-block !important;margin-right:15px;font-size:16px;" class="text-red">خصم</label>
                   <label id="reservation_DiscountOption"></label>
               </div>
               <div class="col-md-6 col-xs-12">
                   <input name="DiscountOption" value="0" id="withoutdiscount" type="radio">
                   <label for="withoutdiscount" style="display:inline-block !important;margin-right:15px;font-size:16px;" class="text-red">بدون خصم</label>
               </div>
               <div class="col-xs-12" id="discountinput">
                   <input name="discount" type="text" placeholder="قيمة الخصم">
                   <label id="reservation_discount"></label>
               </div>
               <div class="col-md-6 col-xs-12">
        <label style="margin-right:15px;">المبلغ المطلوب</label>
        <h2 id="RequireMoney" class="text-red" style="margin:0;margin-right:50px;">

        </h2>
        <input type="hidden" name="reservation_required_money" value="0.00">
    </div>

    <div class="col-md-6 col-xs-12">
        <label style="margin-right:15px;">المبلغ المدفوع</label>
        <input type="text" name="payed" >
        <label id="reservation_payed"></label>
    </div>
    <div class="clearfix">
    </div>
    <div class="text-center">
        <button type="submit" class="main-btn">اضافة حجز</button>
    </div>
            </form>
        </div>
    </div>
    <!-- END Edit Reservation FORM -->

<div role="tabpanel" class="tab-pane fade in active" id="Reservations">
    <button data-popup="AddReservation-Popup" class="main-btn col-xs-3">اضافة حجز</button>
    <form class="col-xs-9">
        <div class="col-xs-12" id="Reservations-Filter">

        </div>
    </form>
    <div class="clearfix"></div>
    <div class="reservations box main-box">
        <table id="Reservations-table" class="list-view">
            <thead>
            <tr>
                <?php foreach($rentings_fields as $field): ?>
                    <th><?php echo e($field); ?></th>
                <?php endforeach; ?>
                <th>الحالة</th>
                <th>الموظف</th>
                <th>الخيارات</th>
            </tr>
            </thead>
            <tbody>


            <?php foreach($rentings as $renting): ?>
                <tr>
                    <td>
                        <?php echo e($renting->id); ?>

                    </td>
                    <td>
                            <a href="/client/-<?php echo e($renting->client->id); ?>"> <?php echo e($renting->client->user->display_name); ?></a>

                    </td>
                    <td>
                            <a href="/car/-<?php echo e($renting->car->id); ?>"><?php echo e($renting->car->name); ?></a>
                    </td>
                    <td>
                        <?php echo e(date_format( new DateTime($renting->start_duration),"Y-m-d")); ?>

                    </td>
                    <td>
                        <?php echo e(date_format( new DateTime($renting->end_duration),"Y-m-d")); ?>

                    </td>
                    <td>
                        <?php echo e($renting->total); ?>

                    </td>
                    <td>
                        <?php echo e($renting->paid); ?>

                    </td>
                    <td>
                        <?php echo e($renting->dept); ?>

                    </td>
                    <td>
                        <?php if($renting->deleted_at == NULL): ?>
                            <span style="padding:5px;" class="btn-primary btn-sm">جديد</span>
                        <?php else: ?>
                            <span style="padding:5px;" class="btn-danger btn-sm">منتهي</span>
                            <?php endif; ?>
                    </td>
                    <td>
                        <?php echo e($renting->user->display_name); ?>

                    </td>
                    <td>
                        <?php if($renting->deleted_at == NULL): ?>
                        <?php /*<button class="main-btn sm-btn" id="UpdateReservation-btn" data-popup="UpdateReservation-Popup" data-id="<?php echo e($renting->id); ?>" */ ?>
                                <?php /*data-car_id="<?php echo e($renting->car_id); ?>"><i class="fa fa-pencil"></i></button>*/ ?>
                        <button class="main-btn sm-btn" id="DeleteReservation-btn" data-popup="DeleteReservation-Popup" data-id="<?php echo e($renting->id); ?>"><i class="fa fa-remove"></i></button>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>

            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('tab-script'); ?>
    <script src="<?php echo e(asset('AjaxRequests/Rentings.js')); ?>"></script>
    <script>
        $("#Reservations-Filter input").attr("placeholder","بحث عن حجز ؟");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
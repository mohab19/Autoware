<?php $__env->startSection('tab-style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    نظرة عامة
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tab-contents'); ?>
    <?php

    ?>
    <div role="tabpanel" class="tab-pane fade in active" id="Overview">
        <article class="statistics">
            <h2 class="title">الاحصائيات</h2>
            <div class="item col-md-3 col-xs-6">
                <a href="<?php echo e(route('clients')); ?>">
                    <div class="box box-orange">
                        <div class="num"><?php echo e($clients->count()); ?></div>
                        <div class="title">عميل </div>
                    </div>
                </a>
            </div>
            <div class="item col-md-3 col-xs-6">
                <a href="<?php echo e(route('employees')); ?>">
                    <div class="box box-red">
                        <div class="num"><?php echo e($employees->count()); ?></div>
                        <div class="title">موظف</div>
                    </div>
                </a>
            </div>
            <div class="item col-md-3 col-xs-6">
                <a href="<?php echo e(route('partners')); ?>">
                    <div class="box box-blue">
                        <div class="num"><?php echo e($partners->count()); ?></div>
                        <div class="title">مالك</div>
                    </div>
                </a>
            </div>
            <div class="item col-md-3 col-xs-6">
                <a href="<?php echo e(route('reservations')); ?>">
                    <div class="box box-green">
                        <div class="num"><?php echo e($rentings->count()); ?></div>
                        <div class="title">حجوزات</div>
                    </div>
                </a>
            </div>
            <div class="item col-md-4 col-xs-6">
                <a href="<?php echo e(route('cars')); ?>">
                    <div class="box box-red">
                        <div class="num"><?php echo e($cars->count()); ?></div>
                        <div class="title">سيارة</div>
                    </div>
                </a>
            </div>
            <div class="item col-md-4 col-xs-6">
                <a href="#available">
                    <div class="box box-orange">
                        <div class="num"><?php echo e($cars_avalible->count()); ?></div>
                        <div class="title">سيارة متاحة</div>
                    </div>
                </a>
            </div>
            <div class="item col-md-4 col-xs-6">
                <a href="<?php echo e(route('waiting')); ?>">
                    <div class="box box-blue">
                        <div class="num"><?php echo e($waitings->count()); ?></div>
                        <div class="title">الانتظار</div>
                    </div>
                </a>
            </div>

            <div class="clearfix"></div>
        </article>
        <article class="Latest-Clients main-box col-md-5-5 col-xs-12">
            <h2 class="title">اخر العملاء</h2>

            <?php foreach($clients->take(6) as $client): ?>
                <a href="/client/-<?php echo e($client->id); ?>"><div class="client">
                        <h4 class="name text-dark"><?php echo e($client->first_name." ".$client->last_name); ?></h4>
                        <h5 class="date text-grey">
                            <h5 class="date text-grey"><?php echo e(date_format($client->created_at,"Y-m-d")); ?></h5>
                        </h5>
                    </div>
                </a>
            <?php endforeach; ?>
        </article>
        <article class="Latest-Employees main-box col-md-5-5 col-xs-12">
            <h2 class="title">اخر الموظفين</h2>
            <?php $employees =$employees->take(6)?>
            <?php foreach($employees as $employee): ?>
                <a href="/employee/-<?php echo e($employee->id); ?>"><div class="employee">
                        <h4 class="name text-dark"><?php echo e($employee->first_name." ".$employee->last_name); ?></h4>
                        <?php /*                        <h4 class="name text-dark"><?php echo e($employee->created_at); ?></h4>*/ ?>
                        <h5 class="date text-grey"><?php echo e(date_format($employee->created_at,"Y-m-d")); ?></h5>
                    </div></a>
            <?php endforeach; ?>
        </article>
        <div class="col-md-8-5 col-xs-12">
            <article class="Latest-Reservations main-box col-xs-12">
                <h2 class="title">اخر الحجوزات</h2>
                <table>
                    <tr class="title">
                        <th>
                            السيارة
                        </th>
                        <th>
                            العميل
                        </th>
                        <th>
                            وقت التسليم
                        </th>
                    </tr>
                    <?php $rentings =$rentings->take(6)?>
                    <?php foreach($rentings as $renting): ?>
                        <tr>
                            <td>
                                <?php if($renting->car): ?>
                                    <a href="/car/-<?php echo e($renting->car->id); ?>"><?php echo e($renting->car->name); ?></a>
                                <?php else: ?>
                                    السيارة محذوفة
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="/client/-<?php echo e($renting->client->id); ?>"><?php echo e($renting->client->user->first_name . " " . $renting->client->user->last_name); ?></a>
                            </td>
                            <td>
                                <?php echo e(date_format( new DateTime($renting->end_duration),"Y-m-d")); ?>

                            </td>
                        </tr>
                    <?php endforeach; ?>

                </table>
            </article>
            <article class="Latest-Reservations main-box col-xs-12">
                <h2 class="title">اخر الانتظارات</h2>
                <table>
                    <tr class="title">
                        <th>
                            السيارة
                        </th>
                        <th>
                            العميل
                        </th>
                        <th>
                            من
                        </th>
                        <th>
                            الي
                        </th>
                    </tr>
                    <?php $waitings = $waitings->take(6)?>
                    <?php foreach($waitings as $waiting): ?>
                        <tr>
                            <td>
                                <a href="/car/-<?php echo e($waiting->car->id); ?>"><?php echo e($waiting->car->name); ?></a>
                            </td>
                            <td>
                                <a href="/client/-<?php echo e($waiting->client->id); ?>"><?php echo e($waiting->client->user->first_name . " " . $renting->client->user->last_name); ?></a>
                            </td>
                            <td>
                                <?php echo e(date_format( new DateTime($waiting->start_duration),"Y-m-d")); ?>

                            </td>
                            <td>
                                <?php echo e(date_format( new DateTime($waiting->end_duration),"Y-m-d")); ?>

                            </td>
                        </tr>
                    <?php endforeach; ?>

                </table>
            </article>
        </div>

        <div class="col-md-3 col-xs-12">
            <article class="Latest-Cars main-box col-xs-12">
                <h2 class="title">اخر السيارات</h2>
                <?php $cars =$cars->take(4)?>
                <?php foreach($cars as $car): ?>
                    <a href="/car/-<?php echo e($car->id); ?>"><div class="car">
                            <div class="image fl-right">
                                <img src="<?php echo e($car->picture); ?>">
                            </div>
                            <div class="text fl-right">
                                <h4 style="padding-top:20px" class="text-dark"><?php echo e($car->name); ?></h4>
                                <h5 class="text-grey"><?php echo e(date_format($car->created_at,"Y-m-d")); ?></h5>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                <?php endforeach; ?>

            </article>
            <article id="available" class="Latest-Cars main-box col-xs-12">
                <h2 class="title"> السيارات المتاحة</h2>
                <?php foreach($cars_avalible as $car): ?>
                    <a href="/car/-<?php echo e($car->id); ?>"><div class="car">
                            <div class="image fl-right">
                                <img src="<?php echo e($car->picture); ?>">
                            </div>
                            <div class="text fl-right">
                                <h4 style="padding-top:20px" class="text-dark"><?php echo e($car->name); ?></h4>
                                <h5 class="text-grey"><?php echo e(date_format($car->created_at,"Y-m-d")); ?></h5>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                <?php endforeach; ?>

            </article>
        </div>



    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('tab-script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
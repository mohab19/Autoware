<?php $__env->startSection('tab-style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    الانتظار
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tab-contents'); ?>
    <div id="DeleteWaiting-Popup" class="popup">
        <i class="fa fa-close text-danger" data-toggle="tooltip" data-placement="left" title="اغلاق"></i>
        <!--===== POPUP TITLE -=====-->
        <div class="popup-title">
            <h2>حذف الحجز</h2>
            <br>
            <hr>
            <hr>
        </div>
        <!--===== POPUP BODY ======-->
        <div class="popup-body text-center">
            <form id="DeleteWaiting" type="POST">
                <h3 class="text-red "> هل انت متأكد بأنك تريد حذف هذا الحجز؟</h3>
                <?php echo csrf_field(); ?>


                <input type="text" class="hidden" name="id" id="IDVal">
                <div class="text-center">
                    <button type="submit" class="main-btn">نعم</button>
                </div>
                <div class="alert"role="alert">

                </div>
            </form>
        </div>
    </div>
    <!-- START ADD Reservation FORM -->
    <div id="AddReservation-Popup" class="popup">
        <i class="fa fa-close text-danger" data-toggle="tooltip" data-placement="left" title="اغلاق"></i>
        <!--===== POPUP TITLE -=====-->
        <div class="popup-title">
            <h2>اضافة حجز جديد</h2>
            <br>
            <hr>
            <hr>
        </div>
        <!--===== POPUP BODY ======-->
        <div class="popup-body">
            <?php echo $__env->make('layouts/reservation_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
    <div id="AddWaiting-Popup" class="popup">
        <i class="fa fa-close text-danger" data-toggle="tooltip" data-placement="left" title="اغلاق"></i>
        <!--===== POPUP TITLE -=====-->
        <div class="popup-title">
            <h2>اضافة حجز علي الانتظار</h2>
            <br>
            <hr>
            <hr>
        </div>
        <!--===== POPUP BODY ======-->
        <div class="popup-body">
            <form id="AddWaiting" >
                <?php echo csrf_field(); ?>

                <div class="col-xs-12 ">
                    <select name="client_id"  class="selectpicker" data-show-subtext="false" data-live-search="true">
                        <option disabled selected value="">اختار العميل</option>
                        <?php foreach($users as $user): ?>
                            <option value="<?php echo e($user->id); ?>" data-subtext="<?php echo e($user->user->phone); ?>"><?php echo e($user->user->display_name); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label id="reservation_user_id"></label>
                </div>
                <div class="col-xs-12 ">
                    <select name="car_id" class="selectpicker" data-show-subtext="false" data-live-search="true">
                        <option disabled selected value="">اختار السيارة</option>
                        <?php foreach($cars as $car): ?>
                            <?php if(!$car->available): ?>
                                <option value="<?php echo e($car->id); ?>" data-subtext="<?php echo e($car->plate); ?>"><?php echo e($car->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </select>
                    <label id="reservation_car_id"></label>
                </div>
                <div class="col-md-6 col-xs-12">
                    <label style="margin-right:15px;">من</label>
                    <input name="start_duration" type="date" placeholder="من">
                    <label id="reservation_start_duration"></label>
                </div>
                <div class="col-md-6 col-xs-12">
                    <label style="margin-right:15px;">الي</label>
                    <input name="end_duration" type="date" placeholder="الي">
                    <label id="reservation_end_duration"></label>
                </div>
                <div class="col-md-6 col-xs-12">
                    <label style="margin-right:15px;">المبلغ المطلوب</label>
                    <h2 id="RequireMoney" class="text-red" style="margin:0;margin-right:50px;">
                        190
                    </h2>
                    <input type="hidden" name="reservation_required_money" value="0.00">
                </div>
                <div class="col-xs-12">
                    <textarea name="notes" placeholder="ملاحظات"></textarea>
                </div>

                <div class="clearfix">
                </div>
                <div class="alert text-center"></div>
                <div class="clearfix">
                </div>
                <div class="text-center">
                    <button type="submit" class="main-btn">اضافة حجز</button>
                </div>
            </form>
        </div>
    </div>
    <!-- END ADD Reservation FORM -->  
<!-- START Edit Reservation FORM -->
    <div id="UpdateWaiting-Popup" class="popup">
        <i class="fa fa-close text-danger" data-toggle="tooltip" data-placement="left" title="اغلاق"></i>
        <!--===== POPUP TITLE -=====-->
        <div class="popup-title">
            <h2> تعديل الحجز </h2>
            <br>
            <hr>
            <hr>
        </div>
        <!--===== POPUP BODY ======-->
        <div class="popup-body">
           <form id="UpdateWaiting">
                 <?php echo csrf_field(); ?>

               <input type="hidden" name="id">
               <div class="col-xs-12 ">
                   <select name="car_id" type="text" placeholder="اسم السيارة">
                       <option value="">اختار السيارة</option>
                       <?php foreach($cars as $car): ?>
                           <?php if(!$car->available): ?>
                               <option value="<?php echo e($car->id); ?>"><?php echo e($car->display_name); ?></option>
                           <?php endif; ?>
                       <?php endforeach; ?>
                   </select>
                   <label id="reservation_car_id"></label>
               </div>
               <div class="col-md-6 col-xs-12">
        <label style="margin-right:15px;">من</label>
        <input name="start_duration" type="date" placeholder="من">
        <label id="reservation_start_duration"></label>
    </div>
    <div class="col-md-6 col-xs-12">
        <label style="margin-right:15px;">الي</label>
        <input name="end_duration" type="date" placeholder="الي">
        <label id="reservation_end_duration"></label>
    </div>
               <div class="col-md-6 col-xs-12">
        <label style="margin-right:15px;">المبلغ المطلوب</label>
        <h2 id="RequireMoney" class="text-red" style="margin:0;margin-right:50px;">

        </h2>
        <input type="hidden" name="reservation_required_money" value="0.00">
    </div>
               <div class="col-xs-12">
                   <textarea name="notes" placeholder="ملاحظات"></textarea>
               </div>
    <div class="clearfix">
    </div>
    <div class="text-center">
        <button type="submit" class="main-btn">تعديل</button>
    </div>
               <div class="alert"></div>
            </form>
        </div>
    </div>
    <!-- END Edit Reservation FORM -->

<div role="tabpanel" class="tab-pane fade in active" id="Waitings">
    <button data-popup="AddWaiting-Popup" class="main-btn col-xs-3">اضافة حجز</button>
    <form class="col-xs-9">
        <div class="col-xs-12" id="Reservations-Filter">

        </div>
    </form>
    <div class="clearfix"></div>
    <div class="reservations box main-box">
        <table id="Reservations-table" class="list-view">
            <thead>
            <tr>
                <?php foreach($waitings_fields as $field): ?>
                    <th><?php echo e($field); ?></th>
                <?php endforeach; ?>
                <th>الخيارات</th>
            </tr>
            </thead>
            <tbody>


            <?php foreach($waitings as $waiting): ?>
                <tr>
                    <td id="client">
                            <a href="/client/-<?php echo e($waiting->client->id); ?>"> <?php echo e($waiting->client->user->display_name); ?></a>

                    </td>
                    <td id="car">
                            <a href="/car/-<?php echo e($waiting->car->id); ?>"><?php echo e($waiting->car->name); ?></a>
                    </td>
                    <td id="start">
                        <?php echo e(date_format( new DateTime($waiting->start_duration),"Y-m-d")); ?>

                    </td>
                    <td id="end">
                        <?php echo e(date_format( new DateTime($waiting->end_duration),"Y-m-d")); ?>

                    </td>
                    <td>
                        <?php echo e($waiting->total); ?>

                    </td>
                    <td id="notes">
                        <?php echo e($waiting->notes); ?>

                    </td>
                    <td>
                        <?php echo e(date('Y-m-d',strtotime($waiting->created_at))); ?>

                    </td>
                    <td>
                        <?php echo e($waiting->user->display_name); ?>

                    </td>
                    <td>
                        <button class="main-btn sm-btn" id="UpdateWaiting-btn" data-popup="UpdateWaiting-Popup" data-update data-waiting="<?php echo e($waiting->id); ?>"  data-client_id="<?php echo e($waiting->client_id); ?>"  data-car_id="<?php echo e($waiting->car_id); ?>"
                                data-car_id="<?php echo e($waiting->car_id); ?>"><i class="fa fa-pencil"></i></button>
                        <button class="main-btn sm-btn" id="DeleteWaiting-btn" data-popup="DeleteWaiting-Popup" data-delete data-id="<?php echo e($waiting->id); ?>"><i class="fa fa-remove"></i></button>
                        <?php if($waiting->car->available): ?>
                            <button class="main-btn sm-btn" id="EndWaiting" data-end data-waiting="<?php echo e($waiting->id); ?>"  data-client_id="<?php echo e($waiting->client_id); ?>"  data-car_id="<?php echo e($waiting->car_id); ?>" data-popup="AddReservation-Popup">
                                    حجز الآن</button>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>

            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('tab-script'); ?>
    <script src="<?php echo e(asset('AjaxRequests/Rentings.js')); ?>"></script>
    <script src="<?php echo e(asset('AjaxRequests/Waitings.js')); ?>"></script>
    <script>
        $("#Reservations-Filter input").attr("placeholder","بحث عن حجز ؟");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
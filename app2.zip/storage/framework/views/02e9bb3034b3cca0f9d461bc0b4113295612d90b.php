<?php $__env->startSection('tab-style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    العملاء
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tab-contents'); ?>

    <!--======= ADD CLIENT FORM ===-->
    <div id="AddClient-Popup" class="popup">
        <i class="fa fa-close text-danger" data-toggle="tooltip" data-placement="left" title="اغلاق"></i>
        <!--===== POPUP TITLE -=====-->
        <div class="popup-title">
            <h2>اضافة عميل جديد</h2>
            <br>
            <hr>
            <hr>
        </div>
        <!--===== POPUP BODY ======-->
        <div class="popup-body">
            <?php echo $__env->make('layouts.clients_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
    <!-- END ADD CLIENT FORM -->

    <div role="tabpanel" class="tab-pane fade in active" id="Clients">
        <button data-popup="AddClient-Popup" class="main-btn col-xs-3">اضافة عميل</button>
        <form class="col-xs-9">
            <div class="col-xs-12" id="Clients-Filter">

            </div>
        </form>
        <div class="clearfix"></div>
        <div class="clients box main-box">
            <table id="Clients-table" class="list-view">
                <thead>
                <tr>
                    <?php foreach($clients_fields as $field): ?>
                        <th><span><?php echo e($field); ?></span></th>
                    <?php endforeach; ?>
                  <th>الخيارات</th>
                </tr>
                </thead>
                <tbody>


                <?php foreach($clients as $client): ?>
                    <tr>
                        <td>
                            <?php echo e($client->first_name." ".$client->last_name); ?>

                        </td>
                        <td>

                            <?php echo e(date_format( new DateTime($client->birthdate),"Y-m-d")); ?>

                        </td>
                        <td>
                            <?php echo e($client->phone); ?>

                        </td>
                        <td>
                            <?php echo e($client->address); ?>

                        </td>
                        <td>
                            <?php echo e($client->national_id); ?>

                        </td>
                        <td>
                            <?php echo e($client->notes); ?>

                        </td>
                        <td>
                           <button class="main-btn sm-btn" id="DeleteUser-btn" data-popup="DeleteUser-Popup" data-id="<?php echo e($client->id); ?>"><i class="fa fa-remove"></i></button>
                            <a href="<?php echo e("/client/"."-".$client->id); ?>"><button class="main-btn sm-btn"><i class="fa fa-info"></i></button></a>

                        </td>
                    </tr>
                <?php endforeach; ?>

                </tbody>
            </table>
        </div>




    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('tab-script'); ?>
    <script src="<?php echo e(asset('AjaxRequests/Clients.js')); ?>"></script>
    <script>
                $("#Clients-Filter input").attr("placeholder","بحث عن عميل ؟");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
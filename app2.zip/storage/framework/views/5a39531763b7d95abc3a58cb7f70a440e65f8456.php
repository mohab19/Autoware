<section class="SideBar">
    <!-- Small Nav tabs -->
    <ul class="nav nav-tabs sm" role="tablist">
        <?php if(Gate::allows('admin',$role)): ?>
            <li role="presentation"
                <?php if($page == "overview"): ?>
                class="active"
                    <?php endif; ?>
            >
                <a href="<?php echo e(URL::route('overview')); ?>" aria-controls="home" >
                    <i class="fa fa-globe"></i>نظرة عامة
                </a>
            </li>
        <?php endif; ?>

        <?php if(Gate::allows('employee',$role)): ?>
            <li role="presentation"
                <?php if($page == "quickaccess"): ?>
                class="active"
                    <?php endif; ?>
            >
                <a href="<?php echo e(URL::route('quickaccess')); ?>" aria-controls="home" >
                    <i class="fa fa-globe"></i>الوصول السريع
                </a>
            </li>
        <?php endif; ?>

        <?php if(Gate::allows('admin',$role) || Gate::allows('employee',$role) ): ?>
            <li role="presentation"
                <?php if($page == "client"): ?>
                class="active"
                    <?php endif; ?>
            >
                <a href="<?php echo e(URL::route('clients')); ?>" aria-controls="profile" >
                    <i class="fa fa-users"></i>العملاء
                </a>
            </li>
        <?php endif; ?>
        <?php if(Gate::allows('admin',$role) ): ?>
            <li role="presentation"
                <?php if($page == "admins"): ?>
                class="active"
                    <?php endif; ?>
            >
                <a href="<?php echo e(URL::route('admins')); ?>" aria-controls="profile" >
                    <i class="fa fa-user-plus"></i>المديرين
                </a>
            </li>
        <?php endif; ?>

        <?php if(Gate::allows('admin',$role)): ?>
            <li role="presentation"
                <?php if($page == "employee"): ?>
                class="active"
                    <?php endif; ?>
            >
                <a href="<?php echo e(URL::route('employees')); ?>" aria-controls="messages" >
                    <i class="fa fa-user"></i>الموظفين
                </a>
            </li>
        <?php endif; ?>

        <?php if(Gate::allows('admin',$role)): ?>
            <li role="presentation"
                <?php if($page == "partner"): ?>
                class="active"
                    <?php endif; ?>
            >
                <a href="<?php echo e(URL::route('partners')); ?>" aria-controls="settings" >
                    <i class="fa fa-exchange"></i>الشركاء
                </a>
            </li>
        <?php endif; ?>

        <?php if(Gate::allows('admin',$role) || Gate::allows('employee',$role)): ?>
            <li role="presentation"
                <?php if($page == "cars"): ?>
                class="active"
                    <?php endif; ?>
            >
                <a href="<?php echo e(URL::route('cars')); ?>" aria-controls="settings" >
                    <i class="fa fa-car"></i>السيارات
                </a>
            </li>
        <?php endif; ?>

        <?php if(Gate::allows('admin',$role) || Gate::allows('employee',$role)): ?>
            <li role="presentation"
                <?php if($page == "reservations"): ?>
                class="active"
                    <?php endif; ?>
            >
                <?php /*<a href="#Reservations" aria-controls="settings" role="tab" data-toggle="tab">*/ ?>
                <a href="<?php echo e(URL::route('reservations')); ?>" aria-controls="settings" >
                    <i class="fa fa-pencil"></i>الحجوزات
                </a>
            </li>
        <?php endif; ?>
        <?php if(Gate::allows('admin',$role) || Gate::allows('employee',$role)): ?>
            <li role="presentation"
                <?php if($page == "waiting"): ?>
                class="active"
                    <?php endif; ?>
            >
                <?php /*<a href="#Reservations" aria-controls="settings" role="tab" data-toggle="tab">*/ ?>
                <a href="<?php echo e(URL::route('waiting')); ?>" aria-controls="settings" >
                    <i class="fa fa-clock-o"></i>الانتظار
                </a>
            </li>
        <?php endif; ?>
        <?php if(Gate::allows('admin',$role) || Gate::allows('employee',$role)): ?>
            <li role="presentation"
                <?php if($page == "recive"): ?>
                class="active"
                    <?php endif; ?>
            >
                <?php /*<a href="#Reservations" aria-controls="settings" role="tab" data-toggle="tab">*/ ?>
                <a href="<?php echo e(URL::route('recive')); ?>" aria-controls="settings" >
                    <i class="fa fa-calendar"></i>الاستلام
                </a>
            </li>
        <?php endif; ?>
        <?php if(Gate::allows('admin',$role) || Gate::allows('employee',$role)): ?>
            <li role="presentation"
                <?php if($page == "expenses"): ?>
                class="active"
                    <?php endif; ?>
            >
                <?php /*<a href="#Reservations" aria-controls="settings" role="tab" data-toggle="tab">*/ ?>
                <a href="<?php echo e(URL::route('expenses')); ?>" aria-controls="settings" >
                    <i class="fa fa-money"></i>مصاريف عامة
                </a>
            </li>
        <?php endif; ?>
        <?php if(Gate::allows('admin',$role)): ?>
            <li role="presentation"
                <?php if($page == "advertisements"): ?>
                class="active"
                    <?php endif; ?>
            >
                <?php /*<a href="#Reservations" aria-controls="settings" role="tab" data-toggle="tab">*/ ?>
                <a href="<?php echo e(URL::route('advertisements')); ?>" aria-controls="settings" >
                    <i class="fa fa-microphone"></i>الاعلانات
                </a>
            </li>
        <?php endif; ?>
        <?php if(Gate::allows('admin',$role)): ?>
            <li role="presentation"
                <?php if($page == "reports"): ?>
                class="active"
                    <?php endif; ?>
            >
                <a href="<?php echo e(URL::route('reports')); ?>" aria-controls="settings" >
                    <i class="fa fa-file-text-o"></i>التقارير
                </a>
            </li>
        <?php endif; ?>

    </ul>
    <!-- Tab panes -->
    <!-- Default Nav tabs -->

    <?php /*---------------------------------------------------------------------------------------------------------*/ ?>
    <ul class="nav nav-tabs default" role="tablist">
        <?php if(Gate::allows('admin',$role)): ?>
            <li role="presentation"
                <?php if($page == "overview"): ?>
                class="active"
                    <?php endif; ?>
            >
                <a href="<?php echo e(URL::route('overview')); ?>" aria-controls="home" >
                    <i class="fa fa-globe"></i>نظرة عامة
                </a>
            </li>
        <?php endif; ?>

        <?php if(Gate::allows('employee',$role)): ?>
            <li role="presentation"
                <?php if($page == "quickaccess"): ?>
                class="active"
                    <?php endif; ?>
            >
                <a href="<?php echo e(URL::route('quickaccess')); ?>" aria-controls="home" >
                    <i class="fa fa-globe"></i>الوصول السريع
                </a>
            </li>
        <?php endif; ?>

        <?php if(Gate::allows('admin',$role) || Gate::allows('employee',$role) ): ?>
            <li role="presentation"
                <?php if($page == "client"): ?>
                class="active"
                    <?php endif; ?>
            >
                <a href="<?php echo e(URL::route('clients')); ?>" aria-controls="profile" >
                    <i class="fa fa-users"></i>العملاء
                </a>
            </li>
        <?php endif; ?>
        <?php if(Gate::allows('admin',$role) ): ?>
            <li role="presentation"
                <?php if($page == "admins"): ?>
                class="active"
                    <?php endif; ?>
            >
                <a href="<?php echo e(URL::route('admins')); ?>" aria-controls="profile" >
                    <i class="fa fa-user-plus"></i>المديرين
                </a>
            </li>
        <?php endif; ?>

        <?php if(Gate::allows('admin',$role)): ?>
            <li role="presentation"
                <?php if($page == "employee"): ?>
                class="active"
                    <?php endif; ?>
            >
                <a href="<?php echo e(URL::route('employees')); ?>" aria-controls="messages" >
                    <i class="fa fa-user"></i>الموظفين
                </a>
            </li>
        <?php endif; ?>

        <?php if(Gate::allows('admin',$role)): ?>
            <li role="presentation"
                <?php if($page == "partner"): ?>
                class="active"
                    <?php endif; ?>
            >
                <a href="<?php echo e(URL::route('partners')); ?>" aria-controls="settings" >
                    <i class="fa fa-exchange"></i>الشركاء
                </a>
            </li>
        <?php endif; ?>

        <?php if(Gate::allows('admin',$role) || Gate::allows('employee',$role)): ?>
            <li role="presentation"
                <?php if($page == "cars"): ?>
                class="active"
                    <?php endif; ?>
            >
                <a href="<?php echo e(URL::route('cars')); ?>" aria-controls="settings" >
                    <i class="fa fa-car"></i>السيارات
                </a>
            </li>
        <?php endif; ?>

        <?php if(Gate::allows('admin',$role) ): ?>
            <li role="presentation"
                <?php if($page == "reservations"): ?>
                class="active"
                    <?php endif; ?>
            >
                <?php /*<a href="#Reservations" aria-controls="settings" role="tab" data-toggle="tab">*/ ?>
                <a href="<?php echo e(URL::route('reservations')); ?>" aria-controls="settings" >
                    <i class="fa fa-pencil"></i>الحجوزات
                </a>
            </li>
        <?php endif; ?>
        <?php if(Gate::allows('admin',$role) || Gate::allows('employee',$role)): ?>
            <li role="presentation"
                <?php if($page == "waiting"): ?>
                class="active"
                    <?php endif; ?>
            >
                <?php /*<a href="#Reservations" aria-controls="settings" role="tab" data-toggle="tab">*/ ?>
                <a href="<?php echo e(URL::route('waiting')); ?>" aria-controls="settings" >
                    <i class="fa fa-clock-o"></i>الانتظار
                </a>
            </li>
        <?php endif; ?>
            <?php if(Gate::allows('admin',$role) || Gate::allows('employee',$role)): ?>
                <li role="presentation"
                    <?php if($page == "recive"): ?>
                    class="active"
                        <?php endif; ?>
                >
                    <?php /*<a href="#Reservations" aria-controls="settings" role="tab" data-toggle="tab">*/ ?>
                    <a href="<?php echo e(URL::route('recive')); ?>" aria-controls="settings" >
                        <i class="fa fa-calendar"></i>الاستلام
                    </a>
                </li>
            <?php endif; ?>
            <?php if(Gate::allows('admin',$role) || Gate::allows('employee',$role)): ?>
                <li role="presentation"
                    <?php if($page == "expenses"): ?>
                    class="active"
                        <?php endif; ?>
                >
                    <?php /*<a href="#Reservations" aria-controls="settings" role="tab" data-toggle="tab">*/ ?>
                    <a href="<?php echo e(URL::route('expenses')); ?>" aria-controls="settings" >
                        <i class="fa fa-money"></i>مصاريف عامة
                    </a>
                </li>
            <?php endif; ?>

            <?php if(Gate::allows('admin',$role)): ?>
                <li role="presentation"
                    <?php if($page == "advertisements"): ?>
                    class="active"
                        <?php endif; ?>
                >
                    <?php /*<a href="#Reservations" aria-controls="settings" role="tab" data-toggle="tab">*/ ?>
                    <a href="<?php echo e(URL::route('advertisements')); ?>" aria-controls="settings" >
                        <i class="fa fa-microphone"></i>الاعلانات
                    </a>
                </li>
            <?php endif; ?>
            <?php if(Gate::allows('admin',$role)): ?>
                <li role="presentation"
                    <?php if($page == "reports"): ?>
                    class="active"
                        <?php endif; ?>
                >
                    <a href="<?php echo e(URL::route('reports')); ?>" aria-controls="settings" >
                        <i class="fa fa-file-text-o"></i>التقارير
                    </a>
                </li>
            <?php endif; ?>
            <?php /*<?php if(Gate::allows('admin',$role)): ?>*/ ?>
                <?php /*<li role="presentation"*/ ?>
                    <?php /*<?php if($page == "settings"): ?>*/ ?>
                    <?php /*class="active"*/ ?>
                        <?php /*<?php endif; ?>*/ ?>
                <?php /*>*/ ?>
                    <?php /*<a href="<?php echo e(URL::route('settings')); ?>" aria-controls="settings" >*/ ?>
                        <?php /*<i class="fa fa-gear"></i>الاعدادات*/ ?>
                    <?php /*</a>*/ ?>
                <?php /*</li>*/ ?>
            <?php /*<?php endif; ?>*/ ?>


    </ul>
    <!-- Tab panes -->
</section>
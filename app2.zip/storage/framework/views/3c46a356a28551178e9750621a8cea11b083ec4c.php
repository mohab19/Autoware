<!doctype html>
<html>

<head>
    <!-- Css Files -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/profile.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/profile2.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/media.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fileinput.min.css')); ?>">
    <link href="http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel="stylesheet">
<?php echo $__env->yieldContent('profile-style'); ?>

    <!-- Css Files -->
    <meta charset="utf-8">
  <title><?php echo $__env->yieldContent('title'); ?></title>
</head>


<body>

<div class="background"></div>

<header>
    <div class="container">
        <div class="fl-right">
            <?php echo $__env->yieldContent('desc'); ?>
        </div>
        <?php if(\Illuminate\Support\Facades\Auth::user()->role_id == 1): ?>
        <div class="fl-left">
            <a href="<?php echo $__env->yieldContent('backto'); ?>">العودة الي لوحة التحكم</a>
        </div>
            <?php else: ?>
            <div class="fl-left">
                <a href="/logout">تسجيل الخروج</a>
            </div>
        <?php endif; ?>
    </div>
</header>

<section class="contents">
    <div class="container">
        <?php echo $__env->yieldContent('contents'); ?>
    </div>
</section>

<footer>
    <div class="container">
        <h5 class="fl-right">2016 | جميع الحقوق محفوظة</h5>
        <h5 class="fl-left">تصميم و تطوير <img src="<?php echo e(asset('images/aptware.png')); ?>" width="35"></h5>
    </div>
</footer>
<?php echo $__env->make('layouts.loading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Js Files -->

<script src="<?php echo e(asset('js/jquery-3.1.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.nicescroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<script src="<?php echo e(asset('AjaxRequests/ErrorHandler.js')); ?>"></script>
<script src="<?php echo e(asset('js/fileinput.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>
<script>$('input[type=date]').datepicker({
        // Consistent format with the HTML5 picker
        dateFormat: 'yy-mm-dd'
    });
</script>
    <?php echo $__env->yieldContent('script'); ?>
<!-- Js Files -->
</body>

</html>

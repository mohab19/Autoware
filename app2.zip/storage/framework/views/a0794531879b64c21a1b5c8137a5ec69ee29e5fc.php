<!doctype html>
<html>
    <head>
        <!-- Css Files -->
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/ui.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <?php echo $__env->yieldContent('styles'); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/media.css')); ?>">
        <!-- Css Files -->
        <meta charset="utf-8">
        <title><?php echo $__env->yieldContent('title'); ?>
        </title>
    </head>
    <body>
        <?php echo $__env->yieldContent('contents'); ?>
        <footer>
            <div class="container">
                <h5 class="fl-right">2016 | جميع الحقوق محفوظة</h5>
                <h5 class="fl-left">تصميم و تطوير <img src="<?php echo e(asset('images/aptware.png')); ?>" width="35"></h5>
            </div>
        </footer>
        
        <script src="<?php echo e(asset('AjaxRequests/ErrorHandler.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery-3.1.0.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery.nicescroll.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>
        <script src="<?php echo e(asset('js/ui.js')); ?>"></script>
        <?php echo $__env->yieldContent('scripts'); ?>
        <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    </body>
</html>
<?php echo $__env->make('layouts.loading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
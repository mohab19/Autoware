<?php $__env->startSection('tab-style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    السيارات
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('tab-contents'); ?>
    <div id="DeleteCar-Popup" class="popup">
        <i class="fa fa-close text-danger" data-toggle="tooltip" data-placement="left" title="اغلاق"></i>
        <!--===== POPUP TITLE -=====-->
        <div class="popup-title">
            <h2>حذف السيارة</h2>
            <br>
            <hr>
            <hr>
        </div>
        <!--===== POPUP BODY ======-->
        <div class="popup-body text-center">
            <form id="DeleteCar" type="POST">
                <h3 class="text-red "> هل انت متأكد بأنك تريد حذف هذه السيارة؟</h3>
                <?php echo csrf_field(); ?>


                <input type="text" class="hidden" name="id" id="IDVal">
                <div class="text-center">
                    <button type="submit" class="main-btn">نعم</button>
                </div>
                <div class="alert"role="alert">

                </div>
            </form>
        </div>
    </div>
    <div id="CheckAvailability-Popup" class="popup">
        <i class="fa fa-close text-danger" data-toggle="tooltip" data-placement="left" title="اغلاق"></i>
        <!--===== POPUP TITLE -=====-->
        <div class="popup-title">
            <h2>معرفة حالة الاتاحة</h2>
            <br>
            <hr>
            <hr>
        </div>
        <!--===== POPUP BODY ======-->
        <div class="popup-body text-center">
            <form id="CheckAvailability" type="POST">
                <?php echo csrf_field(); ?>

                <div class="col-xs-12 ">
                    <select name="id" type="text" placeholder="اسم السيارة">
                        <option value="">اختار السيارة</option>
                        <?php foreach($cars as $car): ?>
                            <option value="<?php echo e($car->id); ?>"><?php echo e($car->display_name); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <label id="availability_car_id"></label>
                </div>
                <div class="text-center">
                    <button type="submit" class="main-btn">تأكيد</button>
                </div>
                <div class="alert"role="alert">

                </div>
            </form>
        </div>
    </div>
    <!-- START ADD CAR FORM -->
    <div id="AddCar-Popup" class="popup">
        <i class="fa fa-close text-danger" data-toggle="tooltip" data-placement="left" title="اغلاق"></i>
        <!--===== POPUP TITLE -=====-->
        <div class="popup-title">
            <h2>اضافة سيارة جديد</h2>
            <br>
            <hr>
            <hr>
        </div>
        <!--===== POPUP BODY ======-->
        <div class="popup-body">
            <form id="car_register" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <?php foreach($cars_register_fields as $register_field): ?>
                    <?php if($register_field['type'] == 'select'): ?>
                        <div class="col-md-6 col-xs-12 ">
                            <select name="<?php echo e($register_field['name']); ?>">
                                <option value=""><?php echo e($register_field['placeholder']); ?></option>
                                <?php foreach($register_field['options'] as $option): ?>
                                    <option value="<?php echo e($option['value']); ?>"><?php echo e($option['display_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <label id="<?php echo e("cars_".$register_field['name']); ?>"></label>
                        </div>
                    <?php else: ?>
                        <div class="col-md-6 col-xs-12 ">
                            <input type="<?php echo e($register_field['type']); ?>" name="<?php echo e($register_field['name']); ?>"
                                   placeholder="<?php echo e($register_field['placeholder']); ?>">
                            <label id="<?php echo e("cars_".$register_field['name']); ?>"></label>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
                <div class="col-xs-12">
                    <textarea name="notes" placeholder="ملاحظات"></textarea>
                </div>
                <div class="col-xs-6">
                    <h5 class="fl-right" style="margin:0;margin-left:30px;margin-top:12px;font-size:18px">الصورة الرئيسية</h5>
                    <input type="file" name="picture" id="car_image">
<label id="cars_picture"></label>
                </div>
                <div class="clearfix">
                </div>
                <div class="alert"></div>
                <div class="clearfix"></div>
                <div class="text-center">
                    <button type="submit" class="main-btn">اضافة سيارة</button>
                </div>
            </form>
        </div>
    </div>
    <!-- END ADD CAR FORM -->



    <div role="tabpanel" class="tab-pane fade in active" id="Cars">
        <button data-popup="AddCar-Popup" style="margin-left:20px" class="main-btn col-md-1 col-xs-3">اضافة </button>
        <button data-popup="CheckAvailability-Popup" class="main-btn col-md-1 col-xs-3">الحالة</button>
        <form class="col-xs-9">
            <div class="col-xs-12" id="Cars-Filter">

            </div>
        </form>
        <div class="clearfix"></div>
        <div class="cars box main-box">
            <table id="Cars-table" class="list-view">
                <thead>
                <tr>
                    <?php foreach($cars_fields as $field): ?>
                        <th><?php echo e($field); ?></th>
                    <?php endforeach; ?>
                    <th>الخيارات</th>
                </tr>
                </thead>
                <tbody>


                <?php foreach($cars as $car): ?>
                    <tr>
                        <td>
                            <img src="<?php echo e($car->picture); ?>" alt="لا يوجد صورة" >
                        </td>
                        <td>
                            <?php echo e($car->name); ?>

                        </td>
                        <td>
                            <?php echo e($car->model); ?>

                        </td>
                        <td>
                            <?php echo e($car->color); ?>

                        </td>
                        <td>
                            <?php echo e($car->plate); ?>

                        </td>
                        <td>
                            <?php echo e($car->KM_Counter); ?>

                        </td>
                        <td>
                            <?php echo e($car->partner->display_name); ?>

                        </td>
                        <td>
                            <?php echo e($car->day_price); ?>

                        </td>
                        <td>
                            <?php echo e($car->month_price); ?>

                        </td>
                        <td>
                            <?php echo e($car->notes); ?>

                        </td>

                        <td>
                            <button class="main-btn sm-btn" data-popup="DeleteCar-Popup" data-id="<?php echo e($car->id); ?>"><i class="fa fa-remove"></i></button>
                            <a href="<?php echo e("/car/"."-".$car->id); ?>"><button class="main-btn sm-btn"><i class="fa fa-info"></i></button></a>
                        </td>
                    </tr>
                <?php endforeach; ?>

                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('tab-script'); ?>
    <script src="<?php echo e(asset('AjaxRequests/Cars.js')); ?>"></script>
    <script>
        $("#Cars-Filter input").attr("placeholder","بحث عن سيارة ؟");
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
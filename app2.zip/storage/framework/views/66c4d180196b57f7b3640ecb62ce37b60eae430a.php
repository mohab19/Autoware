<?php $__env->startSection('tab-style'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    الاعدادات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('tab-contents'); ?>
<div role="tabpanel" class="tab-pane fade in active" id="Reports">
        <h2 class="title text-center">عن الشركة</h2>


        <?php echo csrf_field(); ?>


</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('tab-script'); ?>
    <script src="<?php echo e(asset('AjaxRequests/reports.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
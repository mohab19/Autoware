# KillingShot Academy Web Application


## Instructions

- install any git manager
- Create a folder inside htdocs with name "KillingShot"
- create a database with name "KillingShot"
- Get the project files on it " Explain bottom"

# make the following commands 
- cd "The Folder Location"
- git init
- git remote add origin "The Link that you will find in overview page"
- git fetch && git checkout "Your Branch Name"
Now you have get the project files
- php artisan migrate
- php artisan db:seed

Now you have created the database tables and seeded the user roles.

## APTWARE Software Company
